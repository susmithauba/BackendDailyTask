package com.tritern.evozspecial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvozspecialApplicationTests {

	@Test
	void contextLoads() {
	}

}
